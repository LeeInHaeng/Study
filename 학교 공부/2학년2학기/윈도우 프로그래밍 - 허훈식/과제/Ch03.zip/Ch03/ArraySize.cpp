// ArraySize.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "Ch03.h"
#include "ArraySize.h"
#include "afxdialogex.h"


// CArraySize ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CArraySize, CDialogEx)

CArraySize::CArraySize(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG1, pParent)
	, m_nDlgRow(4)
	, m_nDlgColumn(5)
{

}

CArraySize::~CArraySize()
{
}

void CArraySize::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_Row, m_nDlgRow);
	DDV_MinMaxInt(pDX, m_nDlgRow, 4, 20);
	DDX_Text(pDX, IDC_EDIT_Column, m_nDlgColumn);
	DDV_MinMaxInt(pDX, m_nDlgColumn, 4, 20);
}


BEGIN_MESSAGE_MAP(CArraySize, CDialogEx)
END_MESSAGE_MAP()


// CArraySize �޽��� ó�����Դϴ�.
