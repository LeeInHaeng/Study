package chap10_silsub3;

//2012154036 ������

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class Silsub3 extends JFrame {
	JPanel contentPane = new JPanel();
	JLabel la;
	
	Silsub3(){
		setTitle("Left Ű�� ���ڿ� �ٲٱ�");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setContentPane(contentPane);
		contentPane.addKeyListener(new MyKeyListener());
		la = new JLabel("Love Java");
		//la.setFont(new Font("Arial",Font.PLAIN,30));
		la.setSize(50,50);
		la.setLocation(120,70);
		contentPane.add(la);
		setSize(300,150);
		setVisible(true);
		contentPane.requestFocus();
	}
	class MyKeyListener extends KeyAdapter{
		public void keyPressed(KeyEvent e)
		{
			StringBuffer sb = new StringBuffer(la.getText());
			if(e.getKeyCode() == KeyEvent.VK_LEFT)
			{
				la.setText(sb.reverse().toString());
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Silsub3();
	}

}
