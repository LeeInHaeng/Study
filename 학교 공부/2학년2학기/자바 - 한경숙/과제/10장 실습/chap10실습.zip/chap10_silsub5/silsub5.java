package chap10_silsub5;
// 2012154036 ������

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class silsub5 extends JFrame {
	JPanel contentPane = new JPanel();
	JLabel la = new JLabel();
	
	silsub5(){
		setTitle("+,- Ű�� ��Ʈ ũ�� ����");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setContentPane(contentPane);
		contentPane.addKeyListener(new MyKeyListener());
		la = new JLabel("Love Java");
		la.setFont(new Font("Arial",Font.PLAIN,30));
		la.setLocation(100,50);
		contentPane.add(la);
		setSize(300,150);
		setVisible(true);
		contentPane.requestFocus();
	}
		
	class MyKeyListener extends KeyAdapter{
		public void keyPressed(KeyEvent e){
			if(e.getKeyChar() == '-')
			{
				Font f = la.getFont();
				int size = f.getSize();
				if(size<=5)
					System.out.println("��Ʈ ����� 5 ���Ϸ� ���ϼ� �����ϴ�!");
				else
					la.setFont(new Font("Arial",Font.PLAIN,size-5));
			}
			else if(e.getKeyChar() == '+')
			{
				Font f = la.getFont();
				int size = f.getSize();
				la.setFont(new Font("Arial",Font.PLAIN,size+5));
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new silsub5();
	}

}
