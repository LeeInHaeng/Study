package test;

public class Student {
	private String name;
	private String num;
	private String grade;
	
	public Student(String name, String num, String grade){
		this.name = name;
		this.num = num;
		this.grade = grade;
	}
	
	public String getName(){
		return name;
	}
	
	public String getNum(){
		return num;
	}
	
	public String getGrade(){
		return grade;
	}
}
