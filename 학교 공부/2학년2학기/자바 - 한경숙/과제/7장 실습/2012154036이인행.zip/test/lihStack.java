package test;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class lihStack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<String, Student> dic = new HashMap<String,Student>();
		Scanner scan = new Scanner(System.in);
		String name, grade ,num;
		
		while(true){	
			System.out.println("------------------------");
			System.out.print("�̸��� �Է��ϼ��� (����� \"quit\"�Է�) : ");
			name = scan.next();
			if(name.equals("quit"))
				break;
			if(dic.containsKey(name))
				System.out.println("�ߺ��� �̸��� �ֽ��ϴ�!");
			else
			{
				System.out.print("�й��� �Է��ϼ��� : ");
				num = scan.next();
				System.out.print("������ �Է��ϼ��� : ");
				grade = scan.next();
				
				dic.put(name, new Student(name,num,grade));
			}
		}
		
		Set<String> keys = dic.keySet();
		Iterator<String> it = keys.iterator();
		
		System.out.println("------------------------");
		System.out.println("��ü �����͸� ����մϴ�");
		while(it.hasNext()){
			String key = it.next();
			System.out.println("("+dic.get(key).getName()+","+
			dic.get(key).getNum()+","+dic.get(key).getGrade()+")");
		}
		System.out.println("------------------------");
		
		while(true){
			it = keys.iterator();
			System.out.println("------------------------");
			System.out.print("�˻��� �̸� �Է� (����� \"quit\"�Է�) : ");
			name = scan.next();
			if(name.equals("quit"))
				break;
			
			int i=1;
			while(it.hasNext())
			{
				String key = it.next();
				if(key.equals(name))
				{
					System.out.println("�̸� : " + name);
					System.out.println("�й� : " + dic.get(key).getNum());
					System.out.println("���� : " + dic.get(key).getGrade());
					System.out.println("------------------------");
					i = 0;
					break;
				}
				i = 1;
			}
			if(i==1){
				System.out.println("�������� �ʽ��ϴ�");
				System.out.println("------------------------");
			}
		}
	}
}