package com.example.lih.andpro2;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;

import java.util.ArrayList;

public class CourseActivity extends ListActivity {

    private LinearLayout layout;
    private Button buttons[] = new Button[10];
    private String course_cnt;
    private String tempS[] = new String[100];
    private String courses[];

    private ArrayList<Subject_info> arrList;

    private Intent intent;
    int a=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //layout=(LinearLayout)findViewById(R.id.courseLayout);

        arrList = (ArrayList<Subject_info>) getIntent().getSerializableExtra("ArrList");
        layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);

        tempS[0] = arrList.get(0).getValue("term_name");
        for (int i = 1; i < arrList.size(); i++) {
            String temp;
            temp = arrList.get(i).getValue("term_name");
            if (!(tempS[a].equals(temp))) {
                tempS[++a] = temp;
            } else {
            }
        }
        course_cnt = String.valueOf(a + 1);

        courses = new String[a+1];

        for(int i=0; i<(a+1); i++){
            courses[i] = tempS[i];
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, courses);
        setListAdapter(adapter);

    }

    @Override
    protected void onListItemClick(ListView l, View v,int position, long id){
        String item = (String)getListAdapter().getItem(position);

        if(!item.equals("")) {
            intent = new Intent(CourseActivity.this, Show_course.class);
            // Toast.makeText(getApplicationContext(), b.getText().toString(), Toast.LENGTH_SHORT).show();
            intent.putExtra("TERM", item);
            intent.putExtra("ArrList", arrList);
            startActivity(intent);
        }
    }
}
