package com.example.lih.andpro2;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class FirstActivity extends AppCompatActivity {
    String id;
    String student[] = new String[3];
    Intent in, intent;
    int fileId, imageId, barcodeId;
    ImageButton imgbutton;
    ImageView stImage;
    TextView textView;

    String subject_info[][] = new String[100][7];

    String term;
    int sub_cnt = 0;

    ArrayList<Subject_info> arrList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);

        in = getIntent();
        id = in.getStringExtra("USER_ID");
        fileId = getResources().getIdentifier(id, "raw", getPackageName());
        imageId = getResources().getIdentifier(id, "drawable", getPackageName());
        barcodeId = getResources().getIdentifier(id + "_bar", "drawable", getPackageName());

        readTxt2();
        arrList = new ArrayList<>(100);
        for(int i=0; i<sub_cnt; i++)
            arrList.add(new Subject_info(subject_info[i][0],subject_info[i][1],subject_info[i][2],
                         subject_info[i][3],subject_info[i][4],subject_info[i][5], subject_info[i][6]));


        readTxt(fileId);

        imgbutton = (ImageButton) findViewById(R.id.imgbutton);
        imgbutton.setImageResource(imageId);

        textView = (TextView) findViewById(R.id.textView);
        textView.setText(student[0] + " " + student[1] + " " + student[2]);

        //Toast.makeText(getApplicationContext(),student[0], Toast.LENGTH_SHORT).show();
    }

    public void imageClick(View view) {
        switch (view.getId()) {
            case R.id.imgbutton: // 학생 이미지 바코드 띄우기
                AlertDialog.Builder alert = new AlertDialog.Builder(this);
                LayoutInflater layoutInflater = LayoutInflater.from(this);
                view = layoutInflater.inflate(R.layout.barcode, null);
                stImage = (ImageView) view.findViewById(R.id.stImage);
                stImage.setImageResource(barcodeId);
                alert.setView(view);
                alert.setNeutralButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                alert.show();
                break;

            case R.id.bt1:
                intent = new Intent(this, CourseActivity.class);
                intent.putExtra("ArrList",arrList);
                startActivity(intent);
                break;

            case R.id.bt2:
                intent = new Intent(this, TTActivity.class);
                intent.putExtra("USER_NAME",id);
                startActivity(intent);
                break;

            case R.id.bt3:
                intent = new Intent(this, RetakeActivity.class);
                intent.putExtra("ArrList",arrList);
                intent.putExtra("ArrCopy",arrList);
                startActivity(intent);
                break;

            case R.id.bt4:
                intent = new Intent(this, GraduationActivity.class);
                intent.putExtra("ArrList",arrList);
                startActivity(intent);
                break;

            case R.id.bt5:
                intent = new Intent(this, ZActivity.class);
                startActivity(intent);
                break;

        }
    }

    private void readTxt(int fileId) { // 파일 읽어서 여러 데이터들을 초기화하는 함수
        String data = null;
        InputStream inputStream = getResources().openRawResource(fileId);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        int i, j;
        int cnt = 0;
        try {
            while (true) {
                i = inputStream.read();
                if (i == -1)  // 읽을 문자가 없을 시, 종료
                    break;

                if (i == 38) { // 학과, 학번, 이름
                    j = inputStream.read();
                    while (j != -1) {
                        //  if(String.valueOf(j)=="*") {
                        if (j == 38) {
                            //  i=-1;
                            student[cnt++] = new String(byteArrayOutputStream.toString());
                            byteArrayOutputStream.reset();
                            break;
                        }
                        byteArrayOutputStream.write(j);
                        j = inputStream.read();
                    }
                }
                // 추가 ...
            }

            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void readTxt2() { // 파일 읽어서 여러 데이터들을 초기화하는 함수, 과목 정보
        String data = null;
        InputStream inputStream = getResources().openRawResource(fileId);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        String tmp;
        //  term = "2016년 1학기"; // 나중에 이전 인텐트로부터 값을 넘겨받도록 수정 필요
        int i, j, k;

        int cnt = 0, cnt2 = 0;
        try {
            //     i = inputStream.read();
            while (true) {
                i = inputStream.read();

                // - : 45 , a : 97

                if (i == -1)  // 읽을 문자가 없을 시, 종료
                    break;

                if (i == 58)
                    break;

                if (i == 43) { // 과목 정보 저장
                    while (true) {
                        j = inputStream.read();

                        if (j == 45) {
                            while (true) {
                                k = inputStream.read();
                                if (k == 45) {
                                    subject_info[cnt][cnt2++] = new String(byteArrayOutputStream.toString());
                                    byteArrayOutputStream.reset();

                                    break;
                                } else
                                    byteArrayOutputStream.write(k);
                            }
                        }
                        if (j == 43) {
                            cnt++;
                            cnt2 = 0;
                            sub_cnt++;
                            break;
                        }
                    }
                }
            } // if go 끝
            //   i = inputStream.read();

            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}