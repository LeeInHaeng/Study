package com.example.lih.andpro2;


import android.app.Fragment;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentA extends Fragment {
    private float Neg_Z[][] = new float[35][10];  // n.n , x.xn
    private float Pos_Z[][] = new float[35][10];  // n.n , x.xn

    EditText score, ave, sd;
    TextView res, grade;

    Button button;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_a, container, false);
        button = (Button)view.findViewById(R.id.calc);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Float fscore, fave, fsd, fres;
                fscore = Float.parseFloat(score.getText().toString());
                fave = Float.parseFloat(ave.getText().toString());
                fsd = Float.parseFloat(sd.getText().toString());

                fres = (fscore-fave)/fsd;
                fres *= 100;
                String tmp = fres.toString();
                int x, y;

                float tmp2=0;

                if(fres>349) {
                    res.setText("유효한 값이\n아닙니다.");
                }
                else if(fres<-349) {
                    res.setText("유효한 값이\n아닙니다.");
                }
                else if(fres>0)
                {
                    x = (int)(fres/10); y = (int)(fres%10);
                    tmp2 = 100 - (Pos_Z[x][y] * 100);
                    tmp = String.format("%.2f" ,tmp2);
                    res.setText("상위 "+tmp+"%");

                }
                else if(fres<0)
                {
                    x = (-1)*(int)(fres/10); y = (int)(fres%10)*(-1);
                    tmp2 = 100 - (Neg_Z[x][y] * 100);
                    tmp = String.format("%.2f" ,tmp2);
                    res.setText("상위 "+tmp+"%");
                }
                else if(fres==0)
                {
                    tmp="50.00"; tmp2=50;
                    res.setText("상위 "+tmp+"%");
                }

                if(tmp2<=30) {
                    res.setTextColor(Color.argb(255, 29, 219, 22));
                    grade.setTextColor(Color.argb(255, 29, 219, 22));
                    grade.setText("A");
                }
                else if(tmp2<=70) {
                    res.setTextColor(Color.argb(255, 229, 216, 92));
                    grade.setTextColor(Color.argb(255, 229, 216, 92));
                    grade.setText("B");
                }
                else {
                    res.setTextColor(Color.argb(255, 255, 0, 0));
                    grade.setTextColor(Color.argb(255, 229, 216, 92));
                    grade.setText("C미만");
                }
            }
        });

        score = (EditText)view.findViewById(R.id.score);
        ave = (EditText)view.findViewById(R.id.average);
        sd = (EditText)view.findViewById(R.id.sd);
        res = (TextView)view.findViewById(R.id.result);
        grade = (TextView)view.findViewById(R.id.grade);

        load_NZtable();
        load_PZtable();

        return view;
    }
    private void load_NZtable() { // 파일 읽어서 여러 데이터들을 초기화하는 함수, 과목 정보
        String tmp;
        InputStream inputStream = getResources().openRawResource(R.raw.negative);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        int i, j, k;

        int cnt = 34, cnt2 = 0;
        try {
            //     i = inputStream.read();
            while (true) {
                i = inputStream.read();

                // - : 45 , a : 97

                if (i == -1)  // 읽을 문자가 없을 시, 종료
                    break;

                if (i == 97) { // 과목 정보 저장
                    while (true) {
                        j = inputStream.read();

                        if (j == 46) {
                            while (true) {
                                k = inputStream.read();
                                if (k == 9) {
                                    tmp="0.";
                                    tmp += new String(byteArrayOutputStream.toString());
                                    Neg_Z[cnt][cnt2++] = Float.parseFloat(tmp);
                                    byteArrayOutputStream.reset();

                                    break;
                                } else
                                    byteArrayOutputStream.write(k);
                            }
                        }
                        else if (j == 97) {
                            cnt--;
                            cnt2 = 0;
                            break;
                        }
                        else {}
                    }
                }
            } // if go 끝
            //   i = inputStream.read();

            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void load_PZtable() { // 파일 읽어서 여러 데이터들을 초기화하는 함수, 과목 정보
        String tmp;
        InputStream inputStream = getResources().openRawResource(R.raw.positive);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        int i, j, k;

        int cnt = 0, cnt2 = 0;
        try {
            //     i = inputStream.read();
            while (true) {
                i = inputStream.read();

                // - : 45 , a : 97

                if (i == -1)  // 읽을 문자가 없을 시, 종료
                    break;

                if (i == 97) { // 과목 정보 저장
                    while (true) {
                        j = inputStream.read();

                        if (j == 46) {
                            while (true) {
                                k = inputStream.read();
                                if (k == 9) {
                                    tmp="0.";
                                    tmp += new String(byteArrayOutputStream.toString());
                                    Pos_Z[cnt][cnt2++] = Float.parseFloat(tmp);
                                    byteArrayOutputStream.reset();

                                    break;
                                } else
                                    byteArrayOutputStream.write(k);
                            }
                        }
                        else if (j == 97) {
                            cnt++;
                            cnt2 = 0;
                            break;
                        }
                        else {}
                    }
                }
            } // if go 끝
            //   i = inputStream.read();

            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
