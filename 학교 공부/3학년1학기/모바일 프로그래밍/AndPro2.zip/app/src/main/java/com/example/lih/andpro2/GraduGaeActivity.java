package com.example.lih.andpro2;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import java.util.ArrayList;

public class GraduGaeActivity extends AppCompatActivity {

    private ArrayList<Subject_info> arrList;

    TextView subjects[] = new TextView[8];
    int textId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gradu_gae);

        arrList = (ArrayList<Subject_info>)getIntent().getSerializableExtra("ArrList");
        for(int i=0; i<8; i++){
            String tmp = "text"+(i+1);
            textId = getResources().getIdentifier(tmp,"id",getPackageName());
            subjects[i] = (TextView)findViewById(textId);
        }

        for(int i=0; i<arrList.size(); i++){
            if ("계열기초".equals(arrList.get(i).getValue("category"))) {
                for(int j=0; j<8; j++){
                    if(arrList.get(i).getValue("sub_name").equals(subjects[j].getText().toString()))
                        subjects[j].setTextColor(Color.argb(255, 255, 0, 0));
                }

            }
        }

    }
}