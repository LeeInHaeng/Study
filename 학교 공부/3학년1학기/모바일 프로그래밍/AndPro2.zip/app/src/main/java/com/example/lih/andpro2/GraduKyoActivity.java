package com.example.lih.andpro2;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class GraduKyoActivity extends AppCompatActivity {

    private ArrayList<Subject_info> arrList;
    private LinearLayout lay1, lay2, lay3, lay4;
    private TextView title;
    TextView subjects[] = new TextView[16];
    int textId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gradu_kyo);
        arrList = (ArrayList<Subject_info>)getIntent().getSerializableExtra("ArrList");

        for(int i=0; i<16; i++){
            String tmp = "text"+(i+1);
            textId = getResources().getIdentifier(tmp,"id",getPackageName());
            subjects[i] = (TextView)findViewById(textId);
        }

        for(int i=0; i<arrList.size(); i++){
            if ("핵심교양".equals(arrList.get(i).getValue("category"))) {
                for(int j=0; j<16; j++){
                    if(arrList.get(i).getValue("sub_name").equals(subjects[j].getText().toString()))
                        subjects[j].setTextColor(Color.argb(255, 255, 0, 0));
                }

            }
        }

    }
    public void onClick(View v){
        Intent intent = new Intent(this, KyoShowActivity.class);
        intent.putExtra("ArrList",arrList);
        startActivity(intent);
    }
}
