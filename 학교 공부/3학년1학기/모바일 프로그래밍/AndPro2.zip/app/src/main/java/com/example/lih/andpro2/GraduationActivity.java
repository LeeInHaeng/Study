package com.example.lih.andpro2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class GraduationActivity extends AppCompatActivity {
    private ArrayList<Subject_info> arrList;
    int sum=0;
    int jeon, kyo, haekkyo, gae;
    TextView textView1, textView2;
    Button btn1, btn2, btn3;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graduation);
        arrList = (ArrayList<Subject_info>)getIntent().getSerializableExtra("ArrList");
        textView1 = (TextView)findViewById(R.id.percent);
        textView2 = (TextView)findViewById(R.id.mini);
        btn1 = (Button)findViewById(R.id.kyo);
        btn2 = (Button)findViewById(R.id.jeon);
        btn3 = (Button)findViewById(R.id.gae);

        sum = getPer();

        textView1.setText(String.format("%.0f",((float)sum/150)*100)+"%");
        textView2.setText(sum+"/150  ");


        btn2.setText("전         공             "+jeon+"/75");
        btn1.setText("교         양             "+(kyo+haekkyo)+"/27");
        btn3.setText("계열 기초             "+gae+"/24");




    }

    public int getPer()
    {
        jeon = kyo = haekkyo = gae = 0;

        for(int i=0; i<arrList.size();i++) {
            int tmp = Integer.parseInt(arrList.get(i).getValue("hak"));
            sum += tmp;
            switch(arrList.get(i).getValue("category")){
                case "전공": jeon += tmp;
                    break;
                case "교양": kyo += tmp;
                    break;
                case "핵심교양": haekkyo += tmp;
                    break;
                case "계열기초": gae += tmp;
                    break;
            }
        }
        return sum;
    }

    public void onClick(View view){
        switch (view.getId()){
            case R.id.jeon:
                intent = new Intent(this, GraduJeonActivity.class);
                intent.putExtra("ArrList",arrList);
                startActivity(intent);
                break;

            case R.id.kyo:
                intent = new Intent(this, GraduKyoActivity.class);
                intent.putExtra("ArrList",arrList);
                startActivity(intent);
                break;

            case R.id.gae:
                intent = new Intent(this, GraduGaeActivity.class);
                intent.putExtra("ArrList",arrList);
                startActivity(intent);
                break;

        }
    }
}
