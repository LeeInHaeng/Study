package com.example.lih.andpro2;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class KyoShowActivity extends AppCompatActivity {
    private ArrayList<Subject_info> arrList;
    private LinearLayout layout, lay;
    private TextView title;
    TextView subjects[] = new TextView[40];
    TextView sub2[] = new TextView[40];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        arrList = (ArrayList<Subject_info>)getIntent().getSerializableExtra("ArrList");

        layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);

        title = new TextView(this);
        title.setBackgroundColor(Color.CYAN);
        title.setTextSize(15);
        title.setText("             과목                학점      평점        교수        학기 ");

        layout.addView(title, param);

        for(int i=0; i<arrList.size(); i++){
            if ("교양".equals(arrList.get(i).getValue("category")) || "핵심교양".equals(arrList.get(i).getValue("category")) ) {

                lay = new LinearLayout(this);
                lay.setOrientation(LinearLayout.HORIZONTAL);
                lay.setGravity(Gravity.RIGHT);

                //  int a = arrList.get(i).getValue("sub_name").length();
                subjects[i] = new TextView(this);
                sub2[i] = new TextView(this);

                String tmp = arrList.get(i).getValue("sub_name");
                String tmp2 =
                        arrList.get(i).getValue("term_name").substring(0, 4) +"-"+
                                arrList.get(i).getValue("term_name").substring(6, 7);

                //  Toast.makeText(getApplicationContext(), String.valueOf(cnt2), Toast.LENGTH_SHORT).show();

                subjects[i].setText(tmp);
                sub2[i].setText("       " +
                        arrList.get(i).getValue("hak") + "            " +
                        arrList.get(i).getValue("grade") + "       " +
                        arrList.get(i).getValue("pfs") + "    " + tmp2+"  "
                );
                lay.addView(subjects[i]);
                lay.addView(sub2[i]);

                layout.addView(lay);
            }
        }
        setContentView(layout);
    }
}
