package com.example.lih.andpro2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    Button login,cancel;
    EditText editID,editPass;
    String id,pass, psw;
    int fileId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        login = (Button)findViewById(R.id.login);
        cancel = (Button)findViewById(R.id.cancel);
        editID = (EditText)findViewById(R.id.editID);
        editPass = (EditText)findViewById(R.id.editPass);
    }

    public void btClick(View view){
        id = editID.getText().toString();
        pass = editPass.getText().toString();;
        switch (view.getId()){
            case R.id.login:
                fileId = getResources().getIdentifier(id,"raw",getPackageName());
                //Toast.makeText(getApplicationContext(), String.valueOf(fileId),Toast.LENGTH_SHORT).show();
                if(fileId==0){
                    Toast.makeText(getApplicationContext(),"등록된 사용자가 아닙니다.",Toast.LENGTH_SHORT).show();
                }
                else{
                    readTxt(fileId);
                    if(pass.equals(psw)) {
                        Toast.makeText(getApplicationContext(), "로그인 성공.", Toast.LENGTH_SHORT).show();
                        Intent in = new Intent(this,FirstActivity.class);
                        in.putExtra("USER_ID",id);
                        startActivity(in);
                    }
                    else
                        Toast.makeText(getApplicationContext(),"비밀번호가 틀렸습니다.",Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.cancel:
                //Toast.makeText(getApplicationContext(),"종료",Toast.LENGTH_SHORT).show();
                finish();
                break;
        }
    }

    private void readTxt(int fileId) { // 파일 읽어서 여러 데이터들을 초기화하는 함수
        String data = null;
        InputStream inputStream = getResources().openRawResource(fileId);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        int i, j;
        int cnt=0;
        try {
            while (true) {
                i = inputStream.read();
                if(i==-1)  // 읽을 문자가 없을 시, 종료
                    break;

                if(i==60) { // 비밀번호 저장
                    j= inputStream.read();
                    while (j != -1){
                        //  if(String.valueOf(j)=="*") {
                        if(j==60){
                            //  i=-1;
                            psw = new String(byteArrayOutputStream.toString());
                            byteArrayOutputStream.reset();
                            break;
                        }
                        byteArrayOutputStream.write(j);
                        j= inputStream.read();
                    }
                }
                // 추가 ...
            }

            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
