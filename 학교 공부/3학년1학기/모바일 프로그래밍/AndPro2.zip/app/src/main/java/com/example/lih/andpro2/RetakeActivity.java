package com.example.lih.andpro2;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class RetakeActivity extends AppCompatActivity {
    LinearLayout lay1_1,lay1_2,lay2_1,lay2_2;
    TextView score;
    CheckBox subjects[] = new CheckBox[40];
    TextView subjects_name[] = new TextView[40];
    private ArrayList<Subject_info> arrList, arrCopy;
    int retake_cnt=0;
    float init_ave=0, cp_ave=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_retake);

        arrList = (ArrayList<Subject_info>)getIntent().getSerializableExtra("ArrList");
        arrCopy = (ArrayList<Subject_info>)getIntent().getSerializableExtra("ArrCopy");

        lay1_1 = (LinearLayout)findViewById(R.id.lay1_1);
        lay1_2 = (LinearLayout)findViewById(R.id.lay1_2);

        lay2_1 = (LinearLayout)findViewById(R.id.lay2_1);
        lay2_2 = (LinearLayout)findViewById(R.id.lay2_2);

        score = (TextView)findViewById(R.id.score);


        for(int i=0; i<arrList.size(); i++) {
            init_ave += Float.parseFloat(arrList.get(i).getValue("num_grade"));
        }
        init_ave = init_ave / arrList.size();

        score.setText("평점 평균 : "+init_ave);

        for(int i=0; i<arrList.size(); i++) {

            if( arrList.get(i).getValue("sub_name").equals("프레쉬맨 세미나"))
            {
                continue;
            }
            if( Float.parseFloat(arrList.get(i).getValue("num_grade")) <= 2.5 )
            {
                if(arrList.get(i).getValue("term_name").substring(6, 7).equals("2")){

                    //  int a = arrList.get(i).getValue("sub_name").length();
                    subjects[retake_cnt] = new CheckBox(this);

                    subjects_name[retake_cnt] = new TextView(this);
                    subjects_name[retake_cnt].setTextSize(15);
                    subjects_name[retake_cnt].setPadding(10,8,10,10);
                    subjects[retake_cnt].setText(arrList.get(i).getValue("sub_name"));

                    subjects_name[retake_cnt].setText("     "+arrList.get(i).getValue("hak")+"               "+arrList.get(i).getValue("num_grade"));

                    lay2_1.addView(subjects[retake_cnt]);
                    lay2_2.addView(subjects_name[retake_cnt]);

                    subjects[retake_cnt].setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            boolean checked = ((CheckBox)v).isChecked();

                            int order = findOrder(((CheckBox) v).getText().toString());
                            int order_txt = findOrder2(((CheckBox) v).getText().toString());

                            if(checked)
                            {
                                arrCopy.get(order).setValue("num_grade", "4.0");
                                subjects_name[order_txt].setTextColor(Color.RED);
                                subjects_name[order_txt].setText("     "+arrCopy.get(order).getValue("hak")+"               "+arrCopy.get(order).getValue("num_grade"));
                            }
                            else
                            {
                                arrCopy.get(order).setValue("num_grade", arrList.get(order).getValue("num_grade"));
                                subjects_name[order_txt].setTextColor(Color.BLACK);
                                subjects_name[order_txt].setText("     "+arrCopy.get(order).getValue("hak")+"               "+arrCopy.get(order).getValue("num_grade"));
                            }
                            cp_ave=0;
                            for(int i=0; i<arrCopy.size(); i++) {
                                cp_ave += Float.parseFloat(arrCopy.get(i).getValue("num_grade"));
                            }
                            cp_ave/=arrCopy.size();
                            score.setText("평점 평균 : "+cp_ave);
                        }
                    });
                    retake_cnt++;
                }
                else {
                        subjects[retake_cnt] = new CheckBox(this);
                        subjects_name[retake_cnt] = new TextView(this);
                        subjects_name[retake_cnt].setTextSize(15);
                        subjects_name[retake_cnt].setPadding(10,8,10,10);
                        subjects[retake_cnt].setText(arrList.get(i).getValue("sub_name"));

                        subjects_name[retake_cnt].setText("     "+arrList.get(i).getValue("hak")+"               "+arrList.get(i).getValue("num_grade"));

                        lay1_1.addView(subjects[retake_cnt]);
                        lay1_2.addView(subjects_name[retake_cnt]);

                    subjects[retake_cnt].setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            boolean checked = ((CheckBox)v).isChecked();

                            int order = findOrder(((CheckBox) v).getText().toString());
                            int order_txt = findOrder2(((CheckBox) v).getText().toString());

                            if(checked)
                            {
                                arrCopy.get(order).setValue("num_grade", "4.0");
                                subjects_name[order_txt].setTextColor(Color.RED);
                                subjects_name[order_txt].setText("     "+arrCopy.get(order).getValue("hak")+"               "+arrCopy.get(order).getValue("num_grade"));
                            }
                            else
                            {
                                arrCopy.get(order).setValue("num_grade", arrList.get(order).getValue("num_grade"));
                                subjects_name[order_txt].setTextColor(Color.BLACK);
                                subjects_name[order_txt].setText("     "+arrCopy.get(order).getValue("hak")+"               "+arrCopy.get(order).getValue("num_grade"));
                            }
                            cp_ave=0;
                            for(int i=0; i<arrCopy.size(); i++) {
                                cp_ave += Float.parseFloat(arrCopy.get(i).getValue("num_grade"));
                            }
                            cp_ave/=arrCopy.size();
                            score.setText("평점 평균 : "+cp_ave);
                        }
                    });
                    retake_cnt++;
                } // 1학기 , 계절학기
            }
        }
    }

    public int findOrder(String sub_name)
    {
        for(int i=0; i<arrCopy.size(); i++){
            if(sub_name.equals(arrCopy.get(i).getValue("sub_name")))
                return i;
        }
        return -1;
    }
    public int findOrder2(String sub_name)
    {
        for(int i=0; i<arrCopy.size(); i++){
            if(sub_name.equals(subjects[i].getText().toString())) {
                return i;
            }
        }
        return -1;
    }
}
