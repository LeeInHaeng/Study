package com.example.lih.andpro2;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class Show_course extends AppCompatActivity {

    private LinearLayout layout, lay;

    String term;
    TextView subjects[] = new TextView[10];
    TextView sub2[] = new TextView[10];
    TextView title;
    int remove =0;
    private ArrayList<Subject_info> arrList;
    private ArrayList<Subject_info> tmpList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);

        title = new TextView(this);
        title.setBackgroundColor(Color.CYAN);
        title.setTextSize(15);
        title.setText("                과목                학점     등급     평점     교수 ");

        layout.addView(title, param);

        Intent intent = getIntent();
        term = intent.getStringExtra("TERM");
        arrList = (ArrayList<Subject_info>)getIntent().getSerializableExtra("ArrList");
        tmpList = new ArrayList<Subject_info>(20);

        for(int i=0; i<arrList.size(); i++)
            if (term.equals(arrList.get(i).getValue("term_name")))
                tmpList.add(arrList.get(i));

        for(int i=0; i<tmpList.size(); i++) {
            //  int a = arrList.get(i).getValue("sub_name").length();
            subjects[i] = new TextView(this);
            sub2[i] = new TextView(this);
            String tmp = tmpList.get(i).getValue("sub_name");

            lay = new LinearLayout(this);
            lay.setOrientation(LinearLayout.HORIZONTAL);
            lay.setGravity(Gravity.RIGHT);
         //  Toast.makeText(getApplicationContext(), String.valueOf(cnt2), Toast.LENGTH_SHORT).show();

                subjects[i].setText(tmp);
                sub2[i].setText("       "+
                                tmpList.get(i).getValue("hak") + "          " +
                                tmpList.get(i).getValue("grade") + "       " +
                                tmpList.get(i).getValue("num_grade") + "    " +
                                tmpList.get(i).getValue("pfs") + "       "
                );
            lay.addView(subjects[i]);
            lay.addView(sub2[i]);

            layout.addView(lay);
        }
        float temp=0;
        String tmp;
        for(int i=0;i<tmpList.size();i++){
            temp+=Float.parseFloat(tmpList.get(i).getValue("num_grade"));
        }
        temp=temp/tmpList.size();
        tmp = String.format("%.2f" ,temp);

        TextView textView = new TextView(this);
        textView.setText("\n\n\n\n\n\n학기 평점 : "+tmp);
        textView.setTextSize(30);
        textView.setGravity(Gravity.CENTER);

        if(temp>4.0)
            textView.setTextColor(Color.argb(255,29,219,22));
        else if(temp>3.5)
            textView.setTextColor(Color.argb(255,229,216,92));
        else if(temp>3.0)
            textView.setTextColor(Color.argb(255,255,187,0));
        else
            textView.setTextColor(Color.argb(255,255,0,0));
        layout.addView(textView);
        setContentView(layout);
    }
}
