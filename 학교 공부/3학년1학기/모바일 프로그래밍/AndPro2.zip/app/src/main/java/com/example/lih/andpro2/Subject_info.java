package com.example.lih.andpro2;

import java.io.Serializable;

/**
 * Created by hss49 on 2017-05-23.
 */

public class Subject_info implements Serializable {
    private String term_name;
    private String sub_name;
    private String hak;
    private String grade;
    private String num_grade;
    private String pfs;
    private String category;

    Subject_info(String a, String b, String c, String d, String e, String f, String g)
    {
        term_name = a;
        sub_name=b;
        hak=c;
        grade=d;
        num_grade=e;
        pfs=f;
        category=g;
    }

    public String getValue(String want)
    {
        switch (want)
        {
            case "term_name":  return term_name;

            case "sub_name":  return sub_name;

            case "hak":       return hak;

            case "grade":     return grade;

            case "num_grade": return num_grade;

            case "pfs":        return pfs;

            case "category": return category;
        }
        return "null";
    }

    public void setValue(String want, String val)
    {
        switch (want)
        {
            case "term_name":  term_name=val; break;

            case "sub_name":   sub_name=val; break;

            case "hak":        hak=val; break;

            case "grade":      grade=val; break;

            case "num_grade":  num_grade=val; break;

            case "pfs":         pfs=val; break;

            case "category":  category=val; break;
        }

    }
}
