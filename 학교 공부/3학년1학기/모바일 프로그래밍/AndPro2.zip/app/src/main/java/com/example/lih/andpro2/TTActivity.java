package com.example.lih.andpro2;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class TTActivity extends AppCompatActivity {
    String id;
    int fileId,imageId;
    String course_cnt;
    Integer[] imageIDs ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tt);

        Intent intent = getIntent();
        id=intent.getStringExtra("USER_NAME");
        fileId = getResources().getIdentifier(id, "raw", getPackageName());
        readTxt(fileId);

        imageIDs = new Integer[Integer.parseInt(course_cnt)];

        for(int i=0; i<Integer.parseInt(course_cnt); i++) {
            imageId = getResources().getIdentifier(id+"_tt"+String.valueOf(i+1), "drawable", getPackageName());
            imageIDs[i] = imageId;
        }

        Gallery gallery = (Gallery)findViewById(R.id.gallery);
        gallery.setAdapter(new ImageAdapter(this));

        gallery.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?> parent, View v, int position, long id)
            {
                ImageView imageView = (ImageView)findViewById(R.id.img);
                imageView.setImageResource(imageIDs[position]);
            }
        });
    }

    public class ImageAdapter extends BaseAdapter{
        private Context context;
        private int itemBackground;
        public ImageAdapter(Context c)
        {
            context = c;
        }

        public int getCount(){
            return imageIDs.length;
        }
        public Object getItem(int position){
            return position;
        }
        public long getItemId(int position){
            return position;
        }
        public View getView(int position, View convertView, ViewGroup parent){
            ImageView imageView = new ImageView(context);
            imageView.setImageResource(imageIDs[position]);
            imageView.setLayoutParams(new Gallery.LayoutParams(400, 400));
             imageView.setBackgroundColor(Color.WHITE);
           // imageView.setBackgroundColor(Color.argb(255,250, 236, 197));
            return imageView;
        }
    }
    private void readTxt(int fileId){ // 파일 읽어서 여러 데이터들을 초기화하는 함수
        String data = null;
        InputStream inputStream = getResources().openRawResource(fileId);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        int i, j;
        int cnt=0;
        try {
            while (true) {
                i = inputStream.read();
                if(i==-1)  // 읽을 문자가 없을 시, 종료
                    break;

                if(i==126) { // 학기 수 저장
                    j= inputStream.read();
                    while (j != -1){
                        //  if(String.valueOf(j)=="*") {
                        if(j==126){
                            //  i=-1;
                            course_cnt = new String(byteArrayOutputStream.toString());
                            byteArrayOutputStream.reset();
                            break;
                        }
                        byteArrayOutputStream.write(j);
                        j= inputStream.read();
                    }
                }
            }

            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
