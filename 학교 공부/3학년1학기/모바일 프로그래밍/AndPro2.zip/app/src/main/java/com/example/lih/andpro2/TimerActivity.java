package com.example.lih.andpro2;

import android.icu.util.Calendar;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TimePicker;

public class TimerActivity extends AppCompatActivity {
    TimePicker picker;
    Button button;
    public int hour,min;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timer);

        final Calendar c = Calendar.getInstance();
        hour = c.get(Calendar.HOUR_OF_DAY);
        min = c.get(Calendar.MINUTE);

        picker = (TimePicker)findViewById(R.id.timePicker);
        picker.setHour(hour);
        picker.setMinute(min);

        button = (Button)findViewById(R.id.button);
    }

    public void alarmOK(View view){

    }
}
