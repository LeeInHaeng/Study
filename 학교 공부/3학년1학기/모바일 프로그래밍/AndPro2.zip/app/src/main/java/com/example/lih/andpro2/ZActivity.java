package com.example.lih.andpro2;

import android.app.Fragment;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class ZActivity extends AppCompatActivity {
    private float Neg_Z[][] = new float[35][10];  // n.n , x.xn
    private float Pos_Z[][] = new float[35][10];  // n.n , x.xn

    EditText score, ave, sd;
    TextView res, grade;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_z);

        getFragmentManager().beginTransaction()
                .add(R.id.container, new FragmentA()).commit();
    }

    public void onClick(View view){
        Fragment fr = null;

        switch (view.getId()){
            case R.id.button1:
                fr = new FragmentA();
                break;

            case R.id.button2:
                fr = new FragmentB();
                break;
        }
        getFragmentManager().beginTransaction()
                .replace(R.id.container, fr).commit();
    }
}
