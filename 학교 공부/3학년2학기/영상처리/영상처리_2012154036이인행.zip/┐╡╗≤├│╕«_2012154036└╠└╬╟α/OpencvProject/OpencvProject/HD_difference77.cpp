#include <opencv2\opencv.hpp>

using namespace cv;
using namespace std;

void main()
{
	Mat srcImage, dstImage;
	Mat tmpMatrix;
	Mat channel[3];
	Mat newBgrMat[3];

	srcImage = imread("1920x1080lena.png");
	cv::imshow("srcImage", srcImage);

	split(srcImage, channel);

	// difference mask = 7x7
	// channel[0] = blue, channel[1] = green, channel[2] = red
	// newBgrMat[0] = NewBlueMatrix, newBgrMat[1] = NewGreenMatrix, newBgrMat[2] = NewRedMatrix

	for (int k = 0; k < 3; k++)
	{
		// �ϴ� border �κ��� �����ϰ� ����� �� �ֵ��� ó��
		newBgrMat[k] = Mat::zeros(1080, 1920, CV_8UC1);
		for (int i = 3; i < channel[k].rows - 3; i++)
		{
			for (int j = 3; j < channel[k].cols - 3; j++)
			{
				//int tmp = channel[0].at<uchar>(i,j);
				//cout << tmp;

				int max = -1;
				int tmp;

				tmp = abs(channel[k].at<uchar>(i - 3, j - 3) - channel[k].at<uchar>(i + 3, j + 3));
				if (tmp > max)
					max = tmp;

				tmp = abs(channel[k].at<uchar>(i - 2, j - 3) - channel[k].at<uchar>(i + 2, j + 3));
				if (tmp > max)
					max = tmp;

				tmp = abs(channel[k].at<uchar>(i - 1, j - 3) - channel[k].at<uchar>(i + 1, j + 3));
				if (tmp > max)
					max = tmp;

				tmp = abs(channel[k].at<uchar>(i, j - 3) - channel[k].at<uchar>(i, j + 3));
				if (tmp > max)
					max = tmp;

				tmp = abs(channel[k].at<uchar>(i + 1, j - 3) - channel[k].at<uchar>(i - 1, j + 3));
				if (tmp > max)
					max = tmp;

				tmp = abs(channel[k].at<uchar>(i + 2, j - 3) - channel[k].at<uchar>(i - 2, j + 3));
				if (tmp > max)
					max = tmp;

				tmp = abs(channel[k].at<uchar>(i + 3, j - 3) - channel[k].at<uchar>(i - 3, j + 3));
				if (tmp > max)
					max = tmp;

				////

				tmp = abs(channel[k].at<uchar>(i - 3, j - 2) - channel[k].at<uchar>(i + 3, j + 2));
				if (tmp > max)
					max = tmp;

				tmp = abs(channel[k].at<uchar>(i - 2, j - 2) - channel[k].at<uchar>(i + 2, j + 2));
				if (tmp > max)
					max = tmp;

				tmp = abs(channel[k].at<uchar>(i - 1, j - 2) - channel[k].at<uchar>(i + 1, j + 2));
				if (tmp > max)
					max = tmp;

				tmp = abs(channel[k].at<uchar>(i, j - 2) - channel[k].at<uchar>(i, j + 2));
				if (tmp > max)
					max = tmp;

				tmp = abs(channel[k].at<uchar>(i + 1, j - 2) - channel[k].at<uchar>(i - 1, j + 2));
				if (tmp > max)
					max = tmp;

				tmp = abs(channel[k].at<uchar>(i + 2, j - 2) - channel[k].at<uchar>(i - 2, j + 2));
				if (tmp > max)
					max = tmp;

				tmp = abs(channel[k].at<uchar>(i + 3, j - 2) - channel[k].at<uchar>(i - 3, j + 2));
				if (tmp > max)
					max = tmp;

				////

				tmp = abs(channel[k].at<uchar>(i - 3, j - 1) - channel[k].at<uchar>(i + 3, j + 1));
				if (tmp > max)
					max = tmp;

				tmp = abs(channel[k].at<uchar>(i - 2, j - 1) - channel[k].at<uchar>(i + 2, j + 1));
				if (tmp > max)
					max = tmp;

				tmp = abs(channel[k].at<uchar>(i - 1, j - 1) - channel[k].at<uchar>(i + 1, j + 1));
				if (tmp > max)
					max = tmp;

				tmp = abs(channel[k].at<uchar>(i, j - 1) - channel[k].at<uchar>(i, j + 1));
				if (tmp > max)
					max = tmp;

				tmp = abs(channel[k].at<uchar>(i + 1, j - 1) - channel[k].at<uchar>(i - 1, j + 1));
				if (tmp > max)
					max = tmp;

				tmp = abs(channel[k].at<uchar>(i + 2, j - 1) - channel[k].at<uchar>(i - 2, j + 1));
				if (tmp > max)
					max = tmp;

				tmp = abs(channel[k].at<uchar>(i + 3, j - 1) - channel[k].at<uchar>(i - 3, j + 1));
				if (tmp > max)
					max = tmp;

				////

				tmp = abs(channel[k].at<uchar>(i - 3, j) - channel[k].at<uchar>(i + 3, j));
				if (tmp > max)
					max = tmp;

				tmp = abs(channel[k].at<uchar>(i - 2, j) - channel[k].at<uchar>(i + 2, j));
				if (tmp > max)
					max = tmp;

				tmp = abs(channel[k].at<uchar>(i - 1, j) - channel[k].at<uchar>(i + 1, j));
				if (tmp > max)
					max = tmp;

				newBgrMat[k].at<uchar>(i, j) = max;
			}
		}
	}


	merge(newBgrMat, 3, dstImage);

	cv::imshow("dstImage", dstImage);

	cv::waitKey(0);
}