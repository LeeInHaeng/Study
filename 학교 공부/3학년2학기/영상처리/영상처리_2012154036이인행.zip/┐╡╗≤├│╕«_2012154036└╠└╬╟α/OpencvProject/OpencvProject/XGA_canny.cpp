#include <opencv2\opencv.hpp>

using namespace cv;
using namespace std;

void main()
{
	Mat srcImage;
	Mat channel[3];
	Mat newBgrMat[3];
	Mat dstImage[3];

	srcImage = imread("1024x768lena.png");

	cv::imshow("srcImage", srcImage);

	split(srcImage, channel);

	//Mat gray, edge, draw;
	//cvtColor(src1, gray, CV_BGR2GRAY);

	for (int i = 0; i<3; i++)
		Canny(channel[i], newBgrMat[i], 110, 217, 3);

	merge(newBgrMat, 3, dstImage[0]);
	cv::imshow("3x3 mask dstImage", dstImage[0]);

	for (int i = 0; i<3; i++)
		Canny(channel[i], newBgrMat[i], 110, 217, 5);

	merge(newBgrMat, 3, dstImage[1]);
	cv::imshow("5x5 mask dstImage", dstImage[1]);

	for (int i = 0; i<3; i++)
		Canny(channel[i], newBgrMat[i], 110, 217, 7);

	merge(newBgrMat, 3, dstImage[2]);
	cv::imshow("7x7 mask dstImage", dstImage[2]);

	waitKey(0);
}