#include <opencv2\opencv.hpp>

using namespace cv;
using namespace std;

void main()
{
	Mat srcImage, dstImage;
	Mat tmpMatrix;
	Mat channel[3];
	Mat newBgrMat[3];

	srcImage = imread("1024x768face.jpg");
	cv::imshow("srcImage", srcImage);

	split(srcImage, channel);

	// difference mask = 3x3
	// channel[0] = blue, channel[1] = green, channel[2] = red
	// newBgrMat[0] = NewBlueMatrix, newBgrMat[1] = NewGreenMatrix, newBgrMat[2] = NewRedMatrix

	for (int k = 0; k < 3; k++)
	{
		// �ϴ� border �κ��� �����ϰ� ����� �� �ֵ��� ó��
		newBgrMat[k] = Mat::zeros(768, 1024, CV_8UC1);
		for (int i = 1; i < channel[k].rows - 1; i++)
		{
			for (int j = 1; j < channel[k].cols - 1; j++)
			{
				//int tmp = channel[0].at<uchar>(i,j);
				//cout << tmp;

				int max = -1;
				int tmp;

				tmp = abs(channel[k].at<uchar>(i - 1, j - 1) - channel[k].at<uchar>(i + 1, j + 1));
				if (tmp > max)
					max = tmp;

				tmp = abs(channel[k].at<uchar>(i, j - 1) - channel[k].at<uchar>(i, j + 1));
				if (tmp > max)
					max = tmp;

				tmp = abs(channel[k].at<uchar>(i + 1, j - 1) - channel[k].at<uchar>(i - 1, j + 1));
				if (tmp > max)
					max = tmp;

				tmp = abs(channel[k].at<uchar>(i - 1, j) - channel[k].at<uchar>(i + 1, j));
				if (tmp > max)
					max = tmp;

				newBgrMat[k].at<uchar>(i, j) = max;
			}
		}

		// border ó�� ---> zero padding ���

		// ���� ó��
		// 1��° �÷����� �����ϴ� 0��° �ο�(����) ó��
		for (int i = 1; i < channel[k].cols - 1; i++)
		{
			int max = -1;
			int tmp;

			tmp = abs(channel[k].at<uchar>(0, i + 1) - channel[k].at<uchar>(0, i - 1));
			if (tmp > max)
				max = tmp;

			tmp = abs(channel[k].at<uchar>(1, i + 1) - 0);
			if (tmp > max)
				max = tmp;

			tmp = abs(channel[k].at<uchar>(1, i) - 0);
			if (tmp > max)
				max = tmp;

			tmp = abs(channel[k].at<uchar>(1, i - 1) - 0);
			if (tmp > max)
				max = tmp;

			newBgrMat[k].at<uchar>(0, i) = max;
		}

		// 1��° �÷����� �����ϴ� row��° �ο�(�� �Ʒ�) ó��
		for (int i = 1; i < channel[k].cols - 1; i++)
		{
			int max = -1;
			int tmp = 0;

			tmp = abs(channel[k].at<uchar>(channel[k].rows - 1, i + 1) - channel[k].at<uchar>(channel[k].rows - 1, i - 1));
			if (tmp > max)
				max = tmp;

			tmp = abs(channel[k].at<uchar>(channel[k].rows - 2, i + 1) - 0);
			if (tmp > max)
				max = tmp;

			tmp = abs(channel[k].at<uchar>(channel[k].rows - 2, i) - 0);
			if (tmp > max)
				max = tmp;

			tmp = abs(channel[k].at<uchar>(channel[k].rows - 2, i - 1) - 0);
			if (tmp > max)
				max = tmp;

			newBgrMat[k].at<uchar>(channel[k].rows - 1, i) = max;
		}

		// ���� ó��
		// 1��° �ο���� �����ϴ� 0��° Į��(�� ����) ó��
		for (int i = 1; i < channel[k].rows - 1; i++)
		{
			int max = -1;
			int tmp;

			tmp = abs(channel[k].at<uchar>(i, 1) - 0);
			if (tmp > max)
				max = tmp;

			tmp = abs(channel[k].at<uchar>(i + 1, 1) - 0);
			if (tmp > max)
				max = tmp;

			tmp = abs(channel[k].at<uchar>(i - 1, 0) - channel[k].at<uchar>(i + 1, 0));
			if (tmp > max)
				max = tmp;

			tmp = abs(channel[k].at<uchar>(i - 1, 1) - 0);
			if (tmp > max)
				max = tmp;

			newBgrMat[k].at<uchar>(i, 0) = max;
		}


		// 1��° �ο���� �����ϴ� col��° Į��(�� ������) ó��
		for (int i = 1; i < channel[k].rows - 1; i++)
		{
			int max = -1;
			int tmp;

			tmp = abs(channel[k].at<uchar>(i, channel[k].cols - 2) - 0);
			if (tmp > max)
				max = tmp;

			tmp = abs(channel[k].at<uchar>(i - 1, channel[k].cols - 2) - 0);
			if (tmp > max)
				max = tmp;

			tmp = abs(channel[k].at<uchar>(i - 1, channel[k].cols - 1) - channel[k].at<uchar>(i + 1, channel[k].cols - 1));
			if (tmp > max)
				max = tmp;

			tmp = abs(channel[k].at<uchar>(i + 1, channel[k].cols - 2) - 0);
			if (tmp > max)
				max = tmp;

			newBgrMat[k].at<uchar>(i, channel[k].cols - 1) = max;
		}


		// �𼭸� ó��
		//(0,0) ó��
		int max = -1;
		int tmp;

		tmp = abs(channel[k].at<uchar>(0, 1) - 0);
		if (tmp > max)
			max = tmp;

		tmp = abs(channel[k].at<uchar>(1, 1) - 0);
		if (tmp > max)
			max = tmp;

		tmp = abs(channel[k].at<uchar>(1, 0) - 0);
		if (tmp > max)
			max = tmp;

		newBgrMat[k].at<uchar>(0, 0) = max;

		// �� ������ �� �� ó��
		max = -1;
		tmp = abs(channel[k].at<uchar>(0, channel[k].cols - 2) - 0);
		if (tmp > max)
			max = tmp;

		tmp = abs(channel[k].at<uchar>(1, channel[k].cols - 2) - 0);
		if (tmp > max)
			max = tmp;


		tmp = abs(channel[k].at<uchar>(1, channel[k].cols - 1) - 0);
		if (tmp > max)
			max = tmp;

		newBgrMat[k].at<uchar>(0, channel[k].cols - 1) = max;

		// �� �Ʒ� �� ���� ó��
		max = -1;

		tmp = abs(channel[k].at<uchar>(channel[k].rows - 1, 1) - 0);
		if (tmp > max)
			max = tmp;

		tmp = abs(channel[k].at<uchar>(channel[k].rows - 2, 1) - 0);
		if (tmp > max)
			max = tmp;

		tmp = abs(channel[k].at<uchar>(channel[k].rows - 2, 0) - 0);
		if (tmp > max)
			max = tmp;

		newBgrMat[k].at<uchar>(channel[k].rows - 1, 0) = max;

		// �� �Ʒ� �� ������ ó��
		max = -1;

		tmp = abs(channel[k].at<uchar>(channel[k].rows - 1, channel[k].cols - 2) - 0);
		if (tmp > max)
			max = tmp;

		tmp = abs(channel[k].at<uchar>(channel[k].rows - 2, channel[k].cols - 2) - 0);
		if (tmp > max)
			max = tmp;

		tmp = abs(channel[k].at<uchar>(channel[k].rows - 2, channel[k].cols - 1) - 0);
		if (tmp > max)
			max = tmp;

		newBgrMat[k].at<uchar>(channel[k].rows - 1, channel[k].cols - 1) = max;

	}

	merge(newBgrMat, 3, dstImage);

	cv::imshow("dstImage", dstImage);

	cv::waitKey(0);
}